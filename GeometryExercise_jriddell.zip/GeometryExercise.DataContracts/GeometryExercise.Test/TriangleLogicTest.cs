﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using GeometryExercise.DataContracts;
using System.Collections.Generic;
using GeometryExercise.BusinessLayer;
using System.Linq;
using System.Drawing;

namespace GeometryExercise.Test
{
    [TestClass]
    public class TriangleLogicTest
    {
        public TriangleLogic Logic;

        [TestInitialize]
        public void Initialize()
        {
            var triangleRows = new Dictionary<char, int>() { { 'A', 1 }, { 'B', 2 }, { 'C', 3 }, { 'D', 4 }, { 'E', 5 }, { 'F', 6 } };
            var rowModifier = 10;
            var columnModifier = 10;
            var grid = new TriangleGrid(triangleRows, rowModifier, columnModifier);
            Logic = new TriangleLogic(triangleRows.Keys.ToList(), rowModifier, columnModifier);
        }

        [TestMethod]
        public void IsValidTriangleTestShouldReturnTrue()
        {
            Initialize();
            var point1 = new Point(0, 0);
            var point2 = new Point(10, 0);
            var point3 = new Point(0, 10);
            Assert.IsTrue(Logic.IsValidTriangle(point1, point3, point2, false));
        }

        [TestMethod]
        public void IsValidTriangleTestShouldReturnFalse()
        {
            Initialize();
            var point1 = new Point(0, 0);
            var point2 = new Point(10, 0);
            var point3 = new Point(10, 10);
            Assert.IsFalse(Logic.IsValidTriangle(point1, point3, point2, false));
        }

        [TestMethod]
        public void GetTriangleByNameTestF1()
        {
            Initialize();
            var triangle = Logic.GetTriangleByName('F', 1);
            Assert.AreEqual(triangle.Row, 'F');
            Assert.AreEqual(triangle.Column, 1);
            Assert.AreEqual(triangle.TriangleCoordinatePairs[0], new Point(0, 0));
            Assert.AreEqual(triangle.TriangleCoordinatePairs[1], new Point(0, 10));
            Assert.AreEqual(triangle.TriangleCoordinatePairs[2], new Point(10, 0));
        }

        [TestMethod]
        public void GetTriangleByNameTestF2()
        {
            Initialize();
            var triangle = Logic.GetTriangleByName('F', 2);
            Assert.AreEqual(triangle.Row, 'F');
            Assert.AreEqual(triangle.Column, 2);
            Assert.AreEqual(triangle.TriangleCoordinatePairs[0], new Point(10, 10));
            Assert.AreEqual(triangle.TriangleCoordinatePairs[1], new Point(0, 10));
            Assert.AreEqual(triangle.TriangleCoordinatePairs[2], new Point(10, 0));
        }

        [TestMethod]
        public void GetTriangleByCoordinatesTest()
        {
            Initialize();
            var point1 = new Point(0, 0);
            var point2 = new Point(10, 0);
            var point3 = new Point(0, 10);
            var triangle = Logic.GetTriangleByCoordinates(new List<Point>() { point1, point2, point3 });
            Assert.AreEqual(triangle.Row, 'F');
            Assert.AreEqual(triangle.Column, 1);
        }
    }
}
