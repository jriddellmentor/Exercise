﻿using System;
using System.Collections.Generic;
using System.Linq;
using GeometryExercise.DataContracts;
using System.Drawing;

namespace GeometryExercise.BusinessLayer
{
    /// <summary>
    /// Triangle Logic performs operations against its Triangle Grid.
    /// </summary>
    public class TriangleLogic
    {
        public TriangleGrid Grid { get; set; }

        /// <summary>
        /// Constructor - build up the grid based on letters and modifiers.
        /// </summary>
        /// <param name="rowLetters"></param>
        /// <param name="rowModifier"></param>
        /// <param name="columnModifier"></param>
        public TriangleLogic(List<char> rowLetters, int rowModifier, int columnModifier)
        {
            Grid = new TriangleGrid(new Dictionary<char, int>(), rowModifier, columnModifier);
            for (int row = 0; row < rowLetters.Count; row++)
            {
                Grid.AddRow(rowLetters[row], rowLetters.Count - (row + 1));
            }
        }

        /// <summary>
        /// Get the full triangle object which gives us the three ordered pairs by letter and column, e.g. F1 or F2.
        /// </summary>
        /// <param name="letter"></param>
        /// <param name="column"></param>
        /// <returns></returns>
        public Triangle GetTriangleByName(char letter, int column)
        {
            var triangle = new Triangle()
            {
                Row = letter,
                Column = column
            };
            column--;
            if (!Grid.Rows.ContainsKey(letter))
                throw new Exception(string.Format("GetTriangleByName - No triangle in row '{0}' exists!", letter));
            if (column < 0 || column >= Grid.Rows.Count)
                throw new Exception(string.Format("GetTriangleByName - Column '{0}' does not exist!", column));
            try
            {
                var row = Grid.Rows[letter] * Grid.RowModifier;
                var coordinates = new List<Point>();
                Point point1, point2, point3;
                if (column % 2 == 0)
                {
                    //Lower triangle, note that only the right angle coordinate is affected.
                    point1 = new Point(column * Grid.ColumnModifier, row * Grid.RowModifier);
                    point2 = new Point(column * Grid.ColumnModifier, (row + 1) * Grid.RowModifier);
                    point3 = new Point((column + 1) * Grid.ColumnModifier, row * Grid.RowModifier);
                }
                else
                {
                    //Upper triangle
                    point1 = new Point(column * Grid.ColumnModifier, (row + 1) * Grid.RowModifier);
                    point2 = new Point((column - 1) * Grid.ColumnModifier, (row + 1) * Grid.RowModifier);
                    point3 = new Point(column * Grid.ColumnModifier, row * Grid.RowModifier);
                }
                triangle.TriangleCoordinatePairs = new List<Point>() { point1, point2, point3 };
                return triangle;
            }
            catch
            {
                throw new Exception(string.Format("GetTriangleByName - Unable to find triangle {0}{1}", letter, column));
            }
        }

        /// <summary>
        /// More "web-friendly" method, just pass in the coordinates.
        /// </summary>
        /// <param name="x1"></param>
        /// <param name="y1"></param>
        /// <param name="x2"></param>
        /// <param name="y2"></param>
        /// <param name="x3"></param>
        /// <param name="y3"></param>
        /// <returns></returns>
        public Triangle GetTriangleByCoordinates(int x1, int y1, int x2, int y2, int x3, int y3)
        {
            var points = new List<Point> { new Point(x1, y1), new Point(x2, y2), new Point(x3, y3) };
            return GetTriangleByCoordinates(points);
        }

        /// <summary>
        /// Get the full triangle object which does consist of the letter and column based on the ordered pairs passed in.
        /// </summary>
        /// <param name="points"></param>
        /// <returns></returns>
        public Triangle GetTriangleByCoordinates(List<Point> points)
        {
            //Find the two points with the same x.  Tells us the column.
            if (points == null || points.Count() != 3)
                throw new ArgumentException("GetTriangleByCoordinates requires three points provided!");
            try
            {
                var firstColumnPoint = points.FirstOrDefault(p1 => points.Exists(p2 => p1.X == p2.X && p1.Y != p2.Y));
                points.Remove(firstColumnPoint);
                var secondColumnPoint = points.FirstOrDefault(p => p.X == firstColumnPoint.X && p.Y != firstColumnPoint.Y);
                points.Remove(secondColumnPoint);
                var thirdPoint = points[0];
                if (firstColumnPoint.X > thirdPoint.X)
                {
                    //Upper triangle, first column and second column points are on the right.
                    if (!(IsValidTriangle(firstColumnPoint, secondColumnPoint, thirdPoint, true)))
                        throw new Exception("GetTriangleByCoordinates - not a valid triangle!");
                }
                else
                {
                    //Lower triangle, first column and second column points are on the left.
                    if (!(IsValidTriangle(firstColumnPoint, secondColumnPoint, thirdPoint, false)))
                        throw new Exception("GetTriangleByCoordinates - not a valid triangle!");
                }
                var column = firstColumnPoint.X / Grid.ColumnModifier;
                var letterColumn = Grid.Rows.FirstOrDefault(r => r.Value == column);
                var triangle = new Triangle()
                {
                    Row = letterColumn.Key,
                    Column = letterColumn.Value + 1,
                    TriangleCoordinatePairs = points
                };
                return triangle;
            }
            catch
            {
                throw new Exception("GetTriangleByCoordinates - unable to find triangle from given points.");
            }
        }

        public bool IsValidTriangle(Point firstColumnPoint, Point secondColumnPoint, Point thirdPoint, bool isUpperTriangle)
        {
            //Column points differ by row modifier
            var columnPointDifference = firstColumnPoint.Y - secondColumnPoint.Y;
            if (columnPointDifference != Grid.RowModifier && columnPointDifference != -Grid.RowModifier)
                return false;
            //Row points differ by column modifier
            var rowPointDifference1 = firstColumnPoint.X - thirdPoint.X;
            var rowPointDifference2 = secondColumnPoint.X - thirdPoint.X;
            if (rowPointDifference1 != rowPointDifference2)
                return false;
            if (rowPointDifference1 != Grid.ColumnModifier && rowPointDifference1 != -Grid.ColumnModifier)
                return false;
            //Row points differ by column modifier
            if (isUpperTriangle)
            {
                //Third point is on the top left.
                if (thirdPoint.Y != Math.Max(firstColumnPoint.Y, secondColumnPoint.Y))
                    return false;
            }
            else
            {
                //Third point is on the bottom right.
                if (thirdPoint.Y != Math.Min(firstColumnPoint.Y, secondColumnPoint.Y))
                    return false;
            }
            return true;
        }
    }
}
