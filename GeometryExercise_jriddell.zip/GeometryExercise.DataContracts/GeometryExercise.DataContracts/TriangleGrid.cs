﻿
using System.Collections.Generic;

namespace GeometryExercise.DataContracts
{
    /// <summary>
    /// A triangle grid consists of a dictionary of letters each corresponding to rows, a row modifier like 10, and a column modifier like 10 depending on length/width.
    /// </summary>
    public class TriangleGrid
    {
        public Dictionary<char, int> Rows { get; set; }
        public int RowModifier { get; set; }
        public int ColumnModifier { get; set; }

        public TriangleGrid(Dictionary<char, int> rows, int rowModifier, int columnModifier)
        {
            Rows = rows;
            RowModifier = rowModifier;
            ColumnModifier = columnModifier;
        }

        public void AddRow(char letter, int letterNumber)
        {
            Rows.Add(letter, letterNumber * RowModifier);
        }

    }
}
