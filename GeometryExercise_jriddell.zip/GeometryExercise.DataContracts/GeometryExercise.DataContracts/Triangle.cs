﻿using System.Collections.Generic;
using System.Drawing;

namespace GeometryExercise.DataContracts
{
    /// <summary>
    /// A triangle has a name and three coordinate pairs.
    /// </summary>
    public class Triangle
    {
        private List<Point> _triangleCoordinatePairs;
        public char Row { get; set; }
        public int Column { get; set; }
        public List<Point> TriangleCoordinatePairs
        {
            get
            {
                return _triangleCoordinatePairs;
            }
            set
            {
                //Don't even let 'em pass in fewer or more than three points.
                if (value != null && value.Count == 3)
                    _triangleCoordinatePairs = value;
            }
        }
    }
}
